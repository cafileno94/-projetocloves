<?php

class db {

  //host
  private $host = 'localhost';
  
  //usuario
  private $usuario = 'id10808901_gilson';
  
  // senha 
  private $senha = 'joker18@';
  
  //banco de dados
  private $database = 'id10808901_blocodenotas';

  public function conecta_mysql(){
    // criar a conexao função nativa e esperar 4 paramentos  
    //localização do bo bd, usuario de acesso, senha, banco e dados  
  $con = mysqli_connect($this->host, $this->usuario, $this->senha, $this->database);
// ajustar o chatset de comunicação entre a aplicação e o banco de dados
    mysqli_set_charset($con, 'uft8');
  //verificar se houvfe erro de conexão
    if(mysqli_connect_errno()){
      echo 'Erro ao tentar se conectar com o BD MYSQL: '.mysqli_connect_error();
    }
    return $con;
  }
}
   
?>